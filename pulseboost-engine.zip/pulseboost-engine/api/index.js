import 'dotenv/config';
import express from 'express';
import { v4 as uuid } from 'uuid';
import { createClient } from '@supabase/supabase-js';
import { facebookSession } from '../platforms/facebook.js';
import { youtubeSession } from '../platforms/youtube.js';
import { tiktokSession } from '../platforms/tiktok.js';
import { instagramSession } from '../platforms/instagram.js';
import { twitterSession } from '../platforms/twitter.js';
import { sessionDelay, isActiveHour } from '../core/scheduler.js';
import { proxyStats } from '../core/proxy.js';

const app = express();
app.use(express.json());

// Supabase client
const supabase = createClient(
  process.env.SUPABASE_URL || '',
  process.env.SUPABASE_KEY || ''
);

// API auth middleware
const auth = (req, res, next) => {
  const key = req.headers['x-api-key'];
  if (key !== process.env.API_SECRET) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  next();
};

// ─── ROUTES ───────────────────────────────────────────────────────────────────

// Health check
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    activeHour: isActiveHour(),
    proxy: proxyStats(),
    time: new Date().toISOString(),
  });
});

/**
 * POST /order
 * Create a new delivery order
 *
 * Body: {
 *   platform: 'facebook' | 'youtube' | 'tiktok' | 'instagram' | 'twitter'
 *   url: string
 *   type: string (video, reel, profile, tweet, etc)
 *   quantity: number (sessions to run)
 *   geo: string
 *   actions: string[] (like, save, follow, etc)
 *   user_id: string
 * }
 */
app.post('/order', auth, async (req, res) => {
  const { platform, url, type, quantity = 10, geo = 'Indonesia', actions = ['view'], user_id } = req.body;

  if (!platform || !url) {
    return res.status(400).json({ error: 'platform and url required' });
  }

  const orderId = uuid();

  // Save to Supabase
  const { error } = await supabase.from('orders').insert({
    id: orderId,
    user_id,
    platform,
    url,
    type,
    quantity,
    delivered: 0,
    geo,
    actions,
    status: 'pending',
    created_at: new Date().toISOString(),
  });

  if (error) {
    return res.status(500).json({ error: error.message });
  }

  // Start delivery async
  deliverOrder({ orderId, platform, url, type, quantity, geo, actions });

  res.json({ order_id: orderId, status: 'started', quantity });
});

/**
 * GET /order/:id
 * Check order status
 */
app.get('/order/:id', auth, async (req, res) => {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .eq('id', req.params.id)
    .single();

  if (error) return res.status(404).json({ error: 'Order not found' });
  res.json(data);
});

/**
 * GET /orders/:user_id
 * Get all orders for a user
 */
app.get('/orders/:user_id', auth, async (req, res) => {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .eq('user_id', req.params.user_id)
    .order('created_at', { ascending: false });

  if (error) return res.status(500).json({ error: error.message });
  res.json(data);
});

// ─── DELIVERY ENGINE ──────────────────────────────────────────────────────────

const PLATFORM_MAP = {
  facebook: facebookSession,
  youtube: youtubeSession,
  tiktok: tiktokSession,
  instagram: instagramSession,
  twitter: twitterSession,
};

async function deliverOrder({ orderId, platform, url, type, quantity, geo, actions }) {
  const sessionFn = PLATFORM_MAP[platform];
  if (!sessionFn) return;

  let delivered = 0;
  let failed = 0;

  // Update status to running
  await supabase.from('orders').update({ status: 'running' }).eq('id', orderId);

  for (let i = 0; i < quantity; i++) {
    // Check if active hour — pause if not
    if (!isActiveHour()) {
      await new Promise(r => setTimeout(r, 30 * 60 * 1000)); // wait 30 min
    }

    try {
      const result = await sessionFn({ url, type, geo, actions, warmup: i < 3 });

      if (result.success) {
        delivered++;
      } else {
        failed++;
      }

      // Update progress
      await supabase.from('orders').update({
        delivered,
        failed,
        status: delivered + failed >= quantity ? 'completed' : 'running',
        updated_at: new Date().toISOString(),
      }).eq('id', orderId);

    } catch (e) {
      failed++;
    }

    // Natural delay between sessions
    if (i < quantity - 1) {
      const delay = sessionDelay(10000, 45000);
      await new Promise(r => setTimeout(r, delay));
    }
  }

  // Final status
  await supabase.from('orders').update({
    status: 'completed',
    updated_at: new Date().toISOString(),
  }).eq('id', orderId);
}

// ─── START ────────────────────────────────────────────────────────────────────

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`PulseBoost Engine running on port ${PORT}`);
  console.log(`Active hours: 08:00 - 23:00`);
  console.log(`Proxy pool: ${proxyStats().total} proxies`);
});

export default app;
