import 'dotenv/config';

/**
 * Proxy manager — rotates ISP proxies per session
 * Supports proxy-seller.com format
 */

// Proxy pool — in production, load from DB or env
// Format: host:port:user:pass
const PROXY_POOL = process.env.PROXY_LIST
  ? process.env.PROXY_LIST.split(',').map(parseProxy)
  : [];

function parseProxy(str) {
  const [host, port, user, pass] = str.trim().split(':');
  return { host, port: parseInt(port), user, pass };
}

// Track last used per IP to avoid reuse within cooldown
const usedAt = new Map();
const COOLDOWN_MS = 30 * 60 * 1000; // 30 min cooldown per IP

/**
 * Get a fresh proxy — not used recently
 */
export function getProxy(geo = null) {
  // If no pool configured, return null (no proxy)
  if (PROXY_POOL.length === 0) {
    return null;
  }

  const now = Date.now();
  const available = PROXY_POOL.filter(p => {
    const last = usedAt.get(p.host) || 0;
    return now - last > COOLDOWN_MS;
  });

  if (available.length === 0) {
    // All proxies in cooldown — pick least recently used
    let oldest = PROXY_POOL[0];
    let oldestTime = usedAt.get(oldest.host) || 0;
    for (const p of PROXY_POOL) {
      const t = usedAt.get(p.host) || 0;
      if (t < oldestTime) { oldest = p; oldestTime = t; }
    }
    return oldest;
  }

  // Pick random from available
  const proxy = available[Math.floor(Math.random() * available.length)];
  usedAt.set(proxy.host, now);
  return proxy;
}

/**
 * Mark proxy as used
 */
export function markUsed(proxy) {
  if (proxy) usedAt.set(proxy.host, Date.now());
}

/**
 * Get proxy stats
 */
export function proxyStats() {
  const now = Date.now();
  const available = PROXY_POOL.filter(p => now - (usedAt.get(p.host) || 0) > COOLDOWN_MS).length;
  return {
    total: PROXY_POOL.length,
    available,
    inCooldown: PROXY_POOL.length - available,
  };
}
