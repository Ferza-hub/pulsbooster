import 'dotenv/config';

const BUFFER = parseFloat(process.env.DAILY_BUFFER || '1.25');

// Active hours: 8am - 11pm = 15 hours/day
// 48h window = ~30 active hours total
const ACTIVE_HOURS_PER_DAY = 15;
const DELIVERY_WINDOW_HOURS = 30; // 48h = 2 days × 15 active hours

/**
 * 48-hour delivery schedule
 * Spread total volume across 30 active hours with natural variance
 */
export function schedule48h(totalQty) {
  const buffered = Math.ceil(totalQty * BUFFER);
  const perHour = buffered / DELIVERY_WINDOW_HOURS;

  // Weight: slightly more in first 15 hours (day 1) for instant feel
  // then taper naturally in day 2
  return {
    day1PerHour: Math.ceil(perHour * 1.2), // 20% faster day 1
    day2PerHour: Math.ceil(perHour * 0.8), // taper day 2
    totalBuffered: buffered,
  };
}

/**
 * Sessions to run this hour based on 48h window
 */
export function sessionsThisHour(totalQty, delivered, hoursElapsed) {
  if (delivered >= totalQty) return 0;
  if (hoursElapsed >= DELIVERY_WINDOW_HOURS) return totalQty - delivered;

  const remaining = totalQty - delivered;
  const hoursLeft = DELIVERY_WINDOW_HOURS - hoursElapsed;
  const perHour = remaining / hoursLeft;

  // Natural variance ±20%
  return Math.max(1, Math.round(perHour * (0.8 + Math.random() * 0.4)));
}

/**
 * Hourly weights for natural-looking delivery pattern
 * Peak: 10am-12pm, 7pm-9pm (Indonesia prime time)
 */
const HOURLY_WEIGHTS = {
  8: 0.04, 9: 0.06, 10: 0.09, 11: 0.09,
  12: 0.08, 13: 0.07, 14: 0.05, 15: 0.05,
  16: 0.05, 17: 0.06, 18: 0.07, 19: 0.09,
  20: 0.09, 21: 0.07, 22: 0.05, 23: 0.04,
};

export function weightForHour(hour) {
  return HOURLY_WEIGHTS[hour] || 0.06;
}

/**
 * Random delay between sessions
 * Shorter than before — 48h window needs faster throughput
 */
export function sessionDelay(minMs = 3000, maxMs = 20000) {
  const base = minMs + Math.random() * (maxMs - minMs);
  const noise = (Math.random() - 0.5) * 3000;
  return Math.max(minMs, Math.min(maxMs, base + noise));
}

/**
 * Check if current time is in active window (8am - 11pm)
 */
export function isActiveHour() {
  const hour = new Date().getHours();
  return hour >= 8 && hour <= 23;
}

/**
 * Hours left in active window today
 */
export function hoursLeftToday() {
  const hour = new Date().getHours();
  if (hour < 8) return ACTIVE_HOURS_PER_DAY;
  if (hour > 23) return 0;
  return 23 - hour;
}

/**
 * Estimate completion time for a new order
 */
export function estimateCompletion(qty) {
  const now = new Date();
  const hour = now.getHours();

  // If ordered in active hours, likely done within 24-36h
  // If ordered at night, add wait time
  if (hour >= 8 && hour <= 20) {
    return '24-36 jam';
  }
  return '36-48 jam';
}
