import { chromium } from 'playwright';

// Device fingerprint pool — rotate per session
const DEVICE_POOL = [
  { name: 'iPhone 14', ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1', w: 390, h: 844, mobile: true, platform: 'iPhone' },
  { name: 'Samsung S23', ua: 'Mozilla/5.0 (Linux; Android 13; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36', w: 360, h: 780, mobile: true, platform: 'Android' },
  { name: 'Redmi Note 12', ua: 'Mozilla/5.0 (Linux; Android 12; 2207117BPG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36', w: 393, h: 851, mobile: true, platform: 'Android' },
  { name: 'iPhone 13', ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1', w: 390, h: 844, mobile: true, platform: 'iPhone' },
  { name: 'MacBook Chrome', ua: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', w: 1440, h: 900, mobile: false, platform: 'MacIntel' },
  { name: 'Windows Chrome', ua: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36', w: 1366, h: 768, mobile: false, platform: 'Win32' },
  { name: 'Samsung A54', ua: 'Mozilla/5.0 (Linux; Android 13; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36', w: 360, h: 800, mobile: true, platform: 'Android' },
  { name: 'iPhone 15', ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Mobile/15E148 Safari/604.1', w: 393, h: 852, mobile: true, platform: 'iPhone' },
];

// Language pool per geo
const LANG_MAP = {
  'Indonesia': ['id-ID', 'id'],
  'USA': ['en-US', 'en'],
  'Brazil': ['pt-BR', 'pt'],
  'UK': ['en-GB', 'en'],
  'Germany': ['de-DE', 'de'],
  'Japan': ['ja-JP', 'ja'],
  'default': ['id-ID', 'id'],
};

// Random int between min and max
export const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

// Random float
export const randFloat = (min, max) => Math.random() * (max - min) + min;

// Sleep with gaussian-like distribution (more natural)
export const sleep = (ms) => new Promise(r => setTimeout(r, ms));

export const naturalSleep = async (minMs, maxMs) => {
  const base = rand(minMs, maxMs);
  const jitter = rand(-200, 200);
  await sleep(Math.max(500, base + jitter));
};

// Pick random device
export const randomDevice = () => DEVICE_POOL[rand(0, DEVICE_POOL.length - 1)];

// Pick language for geo
export const langForGeo = (geo) => LANG_MAP[geo] || LANG_MAP['default'];

/**
 * Launch stealth browser with proxy + fingerprint
 */
export async function launchBrowser({ proxyConfig, geo = 'Indonesia', deviceOverride = null }) {
  const device = deviceOverride || randomDevice();
  const [lang] = langForGeo(geo);

  const launchArgs = [
    '--disable-blink-features=AutomationControlled',
    '--disable-features=IsolateOrigins,site-per-process',
    '--no-sandbox',
    '--disable-setuid-sandbox',
    '--disable-dev-shm-usage',
    '--disable-accelerated-2d-canvas',
    '--disable-gpu',
    `--lang=${lang}`,
    '--disable-infobars',
    '--window-position=0,0',
    `--window-size=${device.w},${device.h}`,
  ];

  const browserOptions = {
    headless: true,
    args: launchArgs,
  };

  // Add proxy if configured
  if (proxyConfig) {
    browserOptions.proxy = {
      server: `${proxyConfig.host}:${proxyConfig.port}`,
      username: proxyConfig.user,
      password: proxyConfig.pass,
    };
  }

  const browser = await chromium.launch(browserOptions);

  const context = await browser.newContext({
    userAgent: device.ua,
    viewport: { width: device.w, height: device.h },
    locale: lang,
    timezoneId: geoToTimezone(geo),
    isMobile: device.mobile,
    hasTouch: device.mobile,
    deviceScaleFactor: device.mobile ? 3 : 1,
    extraHTTPHeaders: {
      'Accept-Language': langForGeo(geo).join(','),
      'sec-ch-ua-platform': `"${device.platform}"`,
    },
  });

  // Stealth scripts — override automation detection
  await context.addInitScript(() => {
    // Override webdriver
    Object.defineProperty(navigator, 'webdriver', { get: () => false });

    // Override plugins
    Object.defineProperty(navigator, 'plugins', {
      get: () => [
        { name: 'Chrome PDF Plugin', filename: 'internal-pdf-viewer' },
        { name: 'Chrome PDF Viewer', filename: 'mhjfbmdgcfjbbpaeojofohoefgiehjai' },
        { name: 'Native Client', filename: 'internal-nacl-plugin' },
      ],
    });

    // Override languages
    Object.defineProperty(navigator, 'languages', {
      get: () => ['id-ID', 'id', 'en-US', 'en'],
    });

    // Override permissions
    const originalQuery = window.navigator.permissions.query;
    window.navigator.permissions.query = (parameters) =>
      parameters.name === 'notifications'
        ? Promise.resolve({ state: Notification.permission })
        : originalQuery(parameters);

    // Chrome runtime
    window.chrome = { runtime: {} };

    // Randomize canvas fingerprint slightly
    const getContext = HTMLCanvasElement.prototype.getContext;
    HTMLCanvasElement.prototype.getContext = function(type, ...args) {
      const ctx = getContext.call(this, type, ...args);
      if (type === '2d' && ctx) {
        const origFillText = ctx.fillText.bind(ctx);
        ctx.fillText = function(text, x, y, ...rest) {
          return origFillText(text, x + Math.random() * 0.1, y + Math.random() * 0.1, ...rest);
        };
      }
      return ctx;
    };
  });

  const page = await context.newPage();

  return { browser, context, page, device };
}

/**
 * Scroll naturally with variable speed
 */
export async function naturalScroll(page, options = {}) {
  const {
    direction = 'down',
    distance = rand(300, 800),
    steps = rand(5, 15),
    pauseChance = 0.3,
  } = options;

  const stepSize = distance / steps;

  for (let i = 0; i < steps; i++) {
    const delta = direction === 'down' ? stepSize : -stepSize;
    await page.mouse.wheel(0, delta + rand(-10, 10));
    await naturalSleep(50, 200);

    // Random pause while scrolling
    if (Math.random() < pauseChance) {
      await naturalSleep(500, 2000);
    }
  }
}

/**
 * Natural click with slight position randomization
 */
export async function naturalClick(page, selector, options = {}) {
  const el = await page.$(selector);
  if (!el) return false;

  const box = await el.boundingBox();
  if (!box) return false;

  // Click slightly off-center (human behavior)
  const x = box.x + box.width / 2 + rand(-5, 5);
  const y = box.y + box.height / 2 + rand(-3, 3);

  await page.mouse.move(x, y, { steps: rand(5, 15) });
  await naturalSleep(100, 400);
  await page.mouse.click(x, y);

  return true;
}

/**
 * Session warmup — browse a neutral site first
 */
export async function warmupSession(page) {
  const warmupSites = [
    'https://www.google.com',
    'https://www.bing.com',
    'https://news.google.com',
  ];

  const site = warmupSites[rand(0, warmupSites.length - 1)];

  try {
    await page.goto(site, { waitUntil: 'domcontentloaded', timeout: 15000 });
    await naturalSleep(1500, 3500);
    await naturalScroll(page, { distance: rand(200, 500) });
    await naturalSleep(1000, 2500);
  } catch (e) {
    // Warmup fail is OK, continue anyway
  }
}

/**
 * Map geo to timezone
 */
function geoToTimezone(geo) {
  const map = {
    'Indonesia': 'Asia/Jakarta',
    'USA': 'America/New_York',
    'Brazil': 'America/Sao_Paulo',
    'UK': 'Europe/London',
    'Germany': 'Europe/Berlin',
    'Japan': 'Asia/Tokyo',
    'Australia': 'Australia/Sydney',
    'India': 'Asia/Kolkata',
  };
  return map[geo] || 'Asia/Jakarta';
}
