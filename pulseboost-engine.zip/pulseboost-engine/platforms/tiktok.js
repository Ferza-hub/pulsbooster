import { launchBrowser, naturalScroll, naturalSleep, warmupSession, rand } from '../core/browser.js';
import { getProxy, markUsed } from '../core/proxy.js';

/**
 * TikTok session — FYP views with rewatch loop
 * Most powerful signal: watch 85%+ and rewatch
 */
export async function tiktokSession({ url, geo = 'Indonesia', warmup = true }) {
  const proxy = getProxy(geo);
  let browser;

  try {
    ({ browser } = await launchBrowser({ proxyConfig: proxy, geo }));
    const context = browser.contexts()[0];
    const page = await context.newPage();

    if (warmup) await warmupSession(page);

    // Navigate to video
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await naturalSleep(2000, 4000);

    const result = await watchTikTok(page);

    markUsed(proxy);
    return { success: true, ...result };

  } catch (err) {
    return { success: false, error: err.message };
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

async function watchTikTok(page) {
  // Watch 2-3 random videos first (natural FYP behavior)
  const preWatch = rand(1, 3);

  for (let i = 0; i < preWatch; i++) {
    const preDuration = rand(8000, 25000);
    await naturalSleep(preDuration, preDuration + rand(2000, 5000));

    // Scroll to next video
    await page.keyboard.press('ArrowDown').catch(async () => {
      await naturalScroll(page, { distance: rand(400, 600), steps: rand(3, 6) });
    });
    await naturalSleep(1000, 2000);
  }

  // Now watch target video — 85-100% retention
  const videoDuration = rand(15000, 60000); // TikTok videos 15s-60s
  const watchPct = rand(85, 100) / 100;
  const watchMs = Math.floor(videoDuration * watchPct);

  await naturalSleep(watchMs, watchMs + rand(2000, 5000));

  // Rewatch — critical FYP signal
  const rewatchCount = rand(1, 3);
  for (let r = 0; r < rewatchCount; r++) {
    await naturalSleep(videoDuration, videoDuration + rand(3000, 8000));
  }

  // Engagement
  const roll = Math.random();
  if (roll < 0.3) {
    // Like
    await page.click('[data-e2e="like-icon"]').catch(() => {});
    await naturalSleep(500, 1500);
  } else if (roll < 0.4) {
    // Share (tap then cancel)
    await page.click('[data-e2e="share-icon"]').catch(() => {});
    await naturalSleep(1500, 3000);
    await page.keyboard.press('Escape').catch(() => {});
  }

  return {
    type: 'tiktok_view',
    watchMs,
    rewatchCount,
    retention: Math.round(watchPct * 100),
  };
}
