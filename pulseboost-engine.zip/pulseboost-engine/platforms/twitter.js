import { launchBrowser, naturalScroll, naturalSleep, warmupSession, rand } from '../core/browser.js';
import { getProxy, markUsed } from '../core/proxy.js';

/**
 * Twitter/X session — tweet views, profile visits
 */
export async function twitterSession({ url, type = 'tweet', geo = 'Indonesia', warmup = true, actions = ['view'] }) {
  const proxy = getProxy(geo);
  let browser;

  try {
    ({ browser } = await launchBrowser({ proxyConfig: proxy, geo }));
    const context = browser.contexts()[0];
    const page = await context.newPage();

    if (warmup) await warmupSession(page);

    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await naturalSleep(2000, 5000);

    let result;
    if (type === 'tweet') {
      result = await viewTweet(page, actions);
    } else {
      result = await visitProfile(page, actions);
    }

    markUsed(proxy);
    return { success: true, ...result };

  } catch (err) {
    return { success: false, error: err.message };
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

async function viewTweet(page, actions) {
  await naturalSleep(2000, 4000);

  // Read tweet — scroll slightly
  await naturalScroll(page, { distance: rand(100, 250), steps: rand(3, 6) });
  await naturalSleep(rand(5000, 15000), rand(15000, 30000));

  // Read replies
  await naturalScroll(page, { distance: rand(200, 500) });
  await naturalSleep(3000, 8000);

  const performed = ['view'];

  if (actions.includes('like') && Math.random() > 0.5) {
    await page.click('[data-testid="like"]').catch(() => {});
    performed.push('like');
    await naturalSleep(500, 1500);
  }

  if (actions.includes('bookmark') && Math.random() > 0.7) {
    await page.click('[data-testid="bookmark"]').catch(() => {});
    performed.push('bookmark');
  }

  return { type: 'tweet_view', performed };
}

async function visitProfile(page, actions) {
  await naturalSleep(2000, 5000);
  await naturalScroll(page, { distance: rand(400, 900), steps: rand(6, 14) });
  await naturalSleep(3000, 7000);

  // Open a tweet
  const tweets = await page.$$('[data-testid="tweet"]').catch(() => []);
  if (tweets.length > 0) {
    const tweet = tweets[rand(0, Math.min(3, tweets.length - 1))];
    await tweet.click().catch(() => {});
    await naturalSleep(3000, 7000);
    await page.goBack().catch(() => {});
  }

  const performed = ['profile_visit'];

  if (actions.includes('follow') && Math.random() > 0.8) {
    await page.click('[data-testid="followButton"]').catch(() => {});
    performed.push('follow');
  }

  return { type: 'profile_visit', performed };
}
