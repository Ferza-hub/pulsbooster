import { launchBrowser, naturalScroll, naturalSleep, warmupSession, rand } from '../core/browser.js';
import { getProxy, markUsed } from '../core/proxy.js';

/**
 * Facebook session — deliver watch time or page engagement
 */
export async function facebookSession({ url, type = 'video', geo = 'Indonesia', warmup = true }) {
  const proxy = getProxy(geo);
  let browser, result;

  try {
    ({ browser } = await launchBrowser({ proxyConfig: proxy, geo }));
    const context = browser.contexts()[0];
    const page = await context.newPage();

    // Warmup
    if (warmup) await warmupSession(page);

    // Navigate to target
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await naturalSleep(2000, 4000);

    if (type === 'video') {
      result = await watchFacebookVideo(page);
    } else if (type === 'reel') {
      result = await watchFacebookReel(page);
    } else {
      result = await visitFacebookPage(page);
    }

    markUsed(proxy);
    return { success: true, ...result };

  } catch (err) {
    return { success: false, error: err.message };
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

async function watchFacebookVideo(page) {
  const watchMs = rand(60000, 120000); // 1-2 menit minimum untuk monetisasi

  try {
    // Try to play video
    await page.click('[aria-label="Play"]').catch(() => {});
    await naturalSleep(1000, 2000);

    // Scroll a bit while watching (natural behavior)
    const scrollInterval = setInterval(async () => {
      if (Math.random() > 0.7) {
        await naturalScroll(page, { distance: rand(50, 150), steps: rand(2, 5) }).catch(() => {});
      }
    }, 15000);

    await naturalSleep(watchMs, watchMs + rand(5000, 15000));
    clearInterval(scrollInterval);

    // Occasional interaction
    if (Math.random() > 0.6) {
      await page.click('[aria-label="Like"]').catch(() => {});
      await naturalSleep(500, 1500);
    }

  } catch (e) {
    await naturalSleep(watchMs, watchMs + 5000);
  }

  return { type: 'video', watchMs };
}

async function watchFacebookReel(page) {
  const watchMs = rand(30000, 90000);

  try {
    // Reels often autoplay
    await naturalSleep(2000, 4000);

    // Scroll through a couple reels first
    const preReels = rand(1, 3);
    for (let i = 0; i < preReels; i++) {
      await naturalSleep(10000, 25000);
      // Swipe/scroll to next
      await page.keyboard.press('ArrowDown').catch(() => {});
      await naturalSleep(1000, 2000);
    }

    // Watch target reel
    await naturalSleep(watchMs, watchMs + rand(5000, 20000));

    // Like occasionally
    if (Math.random() > 0.5) {
      await page.click('[aria-label="Like"]').catch(() => {});
    }

  } catch (e) {
    await naturalSleep(watchMs, watchMs + 5000);
  }

  return { type: 'reel', watchMs };
}

async function visitFacebookPage(page) {
  await naturalSleep(3000, 6000);
  await naturalScroll(page, { distance: rand(400, 1000), steps: rand(8, 20) });
  await naturalSleep(2000, 5000);

  // Click on a post occasionally
  if (Math.random() > 0.6) {
    const posts = await page.$$('[data-ad-comet-preview="message"]');
    if (posts.length > 0) {
      const post = posts[rand(0, Math.min(2, posts.length - 1))];
      await post.click().catch(() => {});
      await naturalSleep(3000, 8000);
      await page.goBack().catch(() => {});
    }
  }

  return { type: 'page_visit' };
}
