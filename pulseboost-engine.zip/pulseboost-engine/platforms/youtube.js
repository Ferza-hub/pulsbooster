import { launchBrowser, naturalScroll, naturalSleep, warmupSession, rand, randFloat } from '../core/browser.js';
import { getProxy, markUsed } from '../core/proxy.js';

/**
 * YouTube session — watch time delivery
 * Target: 65-80% retention (sweet spot for algorithm)
 */
export async function youtubeSession({ url, geo = 'Indonesia', warmup = true, retentionPct = null }) {
  const proxy = getProxy(geo);
  let browser;

  try {
    ({ browser } = await launchBrowser({ proxyConfig: proxy, geo }));
    const context = browser.contexts()[0];
    const page = await context.newPage();

    // Warmup — go through Google first
    if (warmup) {
      await page.goto('https://www.google.com', { waitUntil: 'domcontentloaded', timeout: 15000 });
      await naturalSleep(1500, 3000);

      // Search for something related (builds referrer signal)
      const searchTerms = ['youtube video', 'youtube music', 'youtube tutorial', 'cara monetisasi youtube'];
      const term = searchTerms[rand(0, searchTerms.length - 1)];
      await page.fill('textarea[name="q"]', term).catch(() => {});
      await naturalSleep(500, 1200);
      await page.keyboard.press('Enter');
      await naturalSleep(2000, 4000);
    }

    // Navigate to video
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await naturalSleep(2000, 4000);

    // Get video duration
    const duration = await getVideoDuration(page);

    // Calculate watch time — 65-80% retention
    const retention = retentionPct || randFloat(0.65, 0.80);
    const watchMs = Math.floor(duration * retention * 1000);

    // Watch the video
    await watchVideo(page, watchMs, duration);

    markUsed(proxy);
    return {
      success: true,
      duration,
      watchMs,
      retention: Math.round(retention * 100),
    };

  } catch (err) {
    return { success: false, error: err.message };
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

async function getVideoDuration(page) {
  try {
    // Wait for player
    await page.waitForSelector('.ytp-time-duration', { timeout: 10000 });
    const durationText = await page.$eval('.ytp-time-duration', el => el.textContent);
    return parseDuration(durationText);
  } catch {
    // Default 8 minutes if can't get duration
    return 480;
  }
}

function parseDuration(text) {
  const parts = text.split(':').map(Number);
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  return 480;
}

async function watchVideo(page, watchMs, totalDuration) {
  // Click play if needed
  await page.click('.ytp-play-button').catch(() => {});
  await naturalSleep(1000, 2000);

  // Skip ads if any
  await naturalSleep(5000, 7000);
  await page.click('.ytp-skip-ad-button').catch(() => {});
  await naturalSleep(500, 1000);
  await page.click('.ytp-ad-skip-button').catch(() => {});

  const startTime = Date.now();
  let elapsed = 0;

  while (elapsed < watchMs) {
    const remaining = watchMs - elapsed;
    const chunkMs = Math.min(remaining, rand(15000, 45000));

    await naturalSleep(chunkMs, chunkMs + rand(0, 2000));
    elapsed = Date.now() - startTime;

    // Natural behaviors during watch
    const roll = Math.random();

    if (roll < 0.1) {
      // Pause and resume (human behavior)
      await page.click('.ytp-play-button').catch(() => {});
      await naturalSleep(2000, 8000);
      await page.click('.ytp-play-button').catch(() => {});

    } else if (roll < 0.2) {
      // Scroll down to read comments
      await naturalScroll(page, { distance: rand(200, 500) });
      await naturalSleep(3000, 8000);
      await naturalScroll(page, { direction: 'up', distance: rand(200, 500) });

    } else if (roll < 0.25) {
      // Like the video
      await page.click('[aria-label*="like this video"]').catch(() => {});
      await naturalSleep(500, 1500);

    } else if (roll < 0.3) {
      // Rewind 10 seconds (rewatch signal)
      await page.keyboard.press('ArrowLeft');
      await page.keyboard.press('ArrowLeft');
      await naturalSleep(1000, 2000);
    }
  }
}
