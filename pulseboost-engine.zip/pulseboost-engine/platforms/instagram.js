import { launchBrowser, naturalScroll, naturalSleep, warmupSession, naturalClick, rand } from '../core/browser.js';
import { getProxy, markUsed } from '../core/proxy.js';

/**
 * Instagram session — reel views with engagement ratio
 */
export async function instagramSession({ url, type = 'reel', geo = 'Indonesia', warmup = true, actions = ['view'] }) {
  const proxy = getProxy(geo);
  let browser;

  try {
    ({ browser } = await launchBrowser({ proxyConfig: proxy, geo }));
    const context = browser.contexts()[0];
    const page = await context.newPage();

    if (warmup) await warmupSession(page);

    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });
    await naturalSleep(2000, 5000);

    let result;
    if (type === 'reel') {
      result = await watchInstagramReel(page, actions);
    } else if (type === 'profile') {
      result = await visitInstagramProfile(page, actions);
    } else {
      result = await viewInstagramPost(page, actions);
    }

    markUsed(proxy);
    return { success: true, ...result };

  } catch (err) {
    return { success: false, error: err.message };
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}

async function watchInstagramReel(page, actions) {
  // Watch 1-2 random reels first
  const preWatch = rand(1, 2);
  for (let i = 0; i < preWatch; i++) {
    await naturalSleep(rand(8000, 20000), rand(20000, 35000));
    // Swipe to next
    await page.keyboard.press('ArrowDown').catch(async () => {
      await naturalScroll(page, { distance: rand(500, 700) });
    });
    await naturalSleep(1000, 2000);
  }

  // Watch target reel — 75-95% of duration
  const reelDuration = rand(15000, 45000);
  const watchPct = rand(75, 95) / 100;
  const watchMs = Math.floor(reelDuration * watchPct);

  await naturalSleep(watchMs, watchMs + rand(3000, 8000));

  const performed = ['view'];

  // Engagement based on actions array
  if (actions.includes('like') && Math.random() > 0.4) {
    await page.click('[aria-label="Like"]').catch(async () => {
      // Try double tap (mobile behavior)
      const viewport = page.viewportSize();
      if (viewport) {
        await page.tap(viewport.width / 2, viewport.height / 2).catch(() => {});
        await page.tap(viewport.width / 2, viewport.height / 2).catch(() => {});
      }
    });
    performed.push('like');
    await naturalSleep(500, 1500);
  }

  if (actions.includes('save') && Math.random() > 0.7) {
    await page.click('[aria-label="Save"]').catch(() => {});
    performed.push('save');
    await naturalSleep(500, 1000);
  }

  if (actions.includes('follow') && Math.random() > 0.85) {
    await page.click('button:has-text("Follow")').catch(() => {});
    performed.push('follow');
  }

  return { type: 'reel', watchMs, retention: Math.round(watchPct * 100), performed };
}

async function visitInstagramProfile(page, actions) {
  await naturalSleep(2000, 4000);

  // Scroll through profile grid
  await naturalScroll(page, { distance: rand(400, 800), steps: rand(6, 12) });
  await naturalSleep(2000, 5000);

  // Open a post
  const posts = await page.$$('article a').catch(() => []);
  if (posts.length > 0) {
    const post = posts[rand(0, Math.min(5, posts.length - 1))];
    await post.click().catch(() => {});
    await naturalSleep(3000, 7000);

    // Scroll through post
    await naturalScroll(page, { distance: rand(100, 300) });
    await naturalSleep(2000, 4000);

    if (actions.includes('like') && Math.random() > 0.5) {
      await page.click('[aria-label="Like"]').catch(() => {});
    }

    await page.goBack().catch(() => {});
  }

  const performed = ['profile_visit'];
  if (actions.includes('follow') && Math.random() > 0.8) {
    await page.click('button:has-text("Follow")').catch(() => {});
    performed.push('follow');
  }

  return { type: 'profile', performed };
}

async function viewInstagramPost(page, actions) {
  await naturalSleep(2000, 5000);
  await naturalScroll(page, { distance: rand(100, 300) });
  await naturalSleep(2000, 4000);

  const performed = ['view'];

  if (actions.includes('like') && Math.random() > 0.4) {
    await page.click('[aria-label="Like"]').catch(() => {});
    performed.push('like');
  }

  if (actions.includes('save') && Math.random() > 0.6) {
    await page.click('[aria-label="Save"]').catch(() => {});
    performed.push('save');
  }

  return { type: 'post', performed };
}
