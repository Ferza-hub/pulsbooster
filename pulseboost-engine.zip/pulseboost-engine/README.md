# PulseBoost Engine

5-platform delivery engine. Facebook, YouTube, TikTok, Instagram, Twitter/X.

## Stack
- Playwright (browser automation)
- Express (REST API)
- Supabase (orders + campaigns)
- ISP Proxy (proxy-seller.com)

## Setup

```bash
npm install
npx playwright install chromium
cp .env.example .env
# Fill in .env values
```

## Supabase
Run `config/schema.sql` in Supabase SQL editor.

## Start
```bash
npm start
```

## API Endpoints

### Health
```
GET /health
```

### Create Order
```
POST /order
Headers: x-api-key: YOUR_SECRET

Body:
{
  "platform": "youtube",
  "url": "https://youtube.com/watch?v=xxxxx",
  "type": "video",
  "quantity": 50,
  "geo": "Indonesia",
  "actions": ["view"],
  "user_id": "user_123"
}
```

### Check Order
```
GET /order/:id
```

## Platform Types

| Platform  | Types                    | Actions                    |
|-----------|--------------------------|----------------------------|
| facebook  | video, reel, page        | like                       |
| youtube   | video                    | view, like                 |
| tiktok    | video                    | view, like, share          |
| instagram | reel, profile, post      | view, like, save, follow   |
| twitter   | tweet, profile           | view, like, bookmark       |

## Paket Psikologis → Engine Mapping

| Paket            | Platform     | Type    | Qty/bulan | Actions          |
|------------------|--------------|---------|-----------|------------------|
| 🌱 Growing       | IG + TikTok  | reel    | 500       | view, like       |
| 🚀 Siap Monetize | YT + FB      | video   | 200       | view (watch time)|
| 👑 Sukses        | All 5        | mixed   | 1000      | view, like, save |

## Proxy Config (proxy-seller.com)
```
PROXY_LIST=host1:port:user:pass,host2:port:user:pass
```

## Deployment
Deploy to any VPS running Node.js 18+.
DigitalOcean $12/mo droplet cukup untuk 500 sessions/day.
