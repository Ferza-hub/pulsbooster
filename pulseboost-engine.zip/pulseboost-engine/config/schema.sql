-- PulseBoost Engine Schema
-- Run this in Supabase SQL editor

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY,
  user_id TEXT,
  platform TEXT NOT NULL,  -- facebook | youtube | tiktok | instagram | twitter
  url TEXT NOT NULL,
  type TEXT,               -- video | reel | profile | tweet
  quantity INT DEFAULT 10,
  delivered INT DEFAULT 0,
  failed INT DEFAULT 0,
  geo TEXT DEFAULT 'Indonesia',
  actions TEXT[],          -- like | save | follow | view
  status TEXT DEFAULT 'pending', -- pending | running | completed | failed
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for user queries
CREATE INDEX IF NOT EXISTS orders_user_id_idx ON orders(user_id);
CREATE INDEX IF NOT EXISTS orders_status_idx ON orders(status);

-- Campaigns table (user-facing)
CREATE TABLE IF NOT EXISTS campaigns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  name TEXT,
  platform TEXT NOT NULL,
  url TEXT NOT NULL,
  package TEXT,            -- growing | monetize | success
  daily_target INT,
  total_delivered INT DEFAULT 0,
  start_date DATE DEFAULT CURRENT_DATE,
  end_date DATE,
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Delivery log
CREATE TABLE IF NOT EXISTS delivery_log (
  id BIGSERIAL PRIMARY KEY,
  order_id UUID REFERENCES orders(id),
  session_result JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;

-- RLS policies (service role bypasses these)
CREATE POLICY "Users see own orders" ON orders
  FOR SELECT USING (user_id = auth.uid()::text);

CREATE POLICY "Users see own campaigns" ON campaigns
  FOR SELECT USING (user_id = auth.uid()::text);
